def hello(name="World"):
    return f"Hello, {name}!"
