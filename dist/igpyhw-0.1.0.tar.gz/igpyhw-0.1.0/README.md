# My Simple Module

A simple example module.

## Installation
```bash
pip install igpyhw
